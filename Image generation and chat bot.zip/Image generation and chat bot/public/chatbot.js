// public/chatbot.js
const chatWindow = document.getElementById("chatWindow");
const chatInput = document.getElementById("chatInput");
const sendBtn = document.getElementById("sendBtn");

function appendBubble(kind, text) {
  const div = document.createElement("div");
  div.className = `chat-bubble ${kind}`;
  // keep newlines and wrap properly
  div.textContent = text;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

async function sendMessage() {
  const msg = chatInput.value.trim();
  if (!msg) return;
  appendBubble("user", msg);
  chatInput.value = "";
  sendBtn.disabled = true;
  sendBtn.textContent = "Thinking...";

  try {
    const res = await fetch("/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ message: msg })
    });
    const data = await res.json();
    if (data?.reply) {
      // optional: simulate typing effect
      typeText(data.reply);
    } else {
      appendBubble("bot", "No reply from server.");
    }
  } catch (e) {
    console.error(e);
    appendBubble("bot", "Error: failed to get reply.");
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = "Send";
  }
}

// Simple typing animation: gradually append characters
function typeText(fullText) {
  const bubble = document.createElement("div");
  bubble.className = "chat-bubble bot";
  chatWindow.appendChild(bubble);
  chatWindow.scrollTop = chatWindow.scrollHeight;

  let i = 0;
  const step = () => {
    i += Math.max(1, Math.floor(fullText.length / 60)); // speed adjust
    bubble.textContent = fullText.slice(0, i);
    chatWindow.scrollTop = chatWindow.scrollHeight;
    if (i < fullText.length) {
      requestAnimationFrame(step);
    }
  };
  step();
}

sendBtn.addEventListener("click", sendMessage);
chatInput.addEventListener("keydown", e => {
  if (e.key === "Enter") sendMessage();
});

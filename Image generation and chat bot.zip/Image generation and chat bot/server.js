// server.js
import express from "express";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import { GoogleGenAI, Modality } from "@google/genai";

dotenv.config();
const PORT = process.env.PORT || 3003;
const app = express();
const __dirname = path.resolve();

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

// Initialize Gemini client
const genAI = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

// Ensure images directory exists
const IMAGES_DIR = path.join(__dirname, "public", "images");
if (!fs.existsSync(IMAGES_DIR)) fs.mkdirSync(IMAGES_DIR, { recursive: true });

// Hidden logs (not shown on UI)
const HISTORY_LOG = path.join(__dirname, "history.log");     // stores prompts/messages (hidden)
const DELETION_LOG = path.join(__dirname, "deletion.log");   // stores deletion events (no prompt text)

// Helper to append to history (hidden)
function appendHistory(text) {
  const entry = `[${new Date().toISOString()}] ${text}\n`;
  fs.appendFileSync(HISTORY_LOG, entry, "utf8");
}

// Helper to log deletion without prompt text
function logDeletion(action, fileName) {
  const entry = `[${new Date().toISOString()}] ACTION: ${action} | FILE: ${fileName}\n`;
  fs.appendFileSync(DELETION_LOG, entry, "utf8");
}

// In-memory history index (for UI downloads). Contains objects: { prompt, fileName, url }
let historyIndex = [];

/**
 * POST /generate
 * Body: { prompt: "..." }
 * Generates an image using Gemini and saves it to public/images.
 * Returns: { downloadUrl: "/images/..." }
 */
app.post("/generate", async (req, res) => {
  try {
    const prompt = (req.body.prompt || "").toString().trim();
    if (!prompt) return res.status(400).json({ error: "Prompt required" });

    // Record hidden history (but we'll not expose prompts in logs for deletions)
    appendHistory(`IMAGE_PROMPT: ${prompt}`);

    const response = await genAI.models.generateContent({
      model: "gemini-2.0-flash-preview-image-generation",
      contents: prompt,
      config: { responseModalities: [Modality.TEXT, Modality.IMAGE] },
    });

    // Find base64 image in response
    let imageBase64 = null;
    const candidate = response?.candidates?.[0];
    if (candidate && Array.isArray(candidate.content?.parts)) {
      for (const part of candidate.content.parts) {
        if (part.inlineData && part.inlineData.data) {
          imageBase64 = part.inlineData.data;
          break;
        }
      }
    }

    if (!imageBase64) {
      console.error("No image data found from Gemini response:", response);
      return res.status(500).json({ error: "No image returned by model" });
    }

    // Save file
    const fileName = `image_${Date.now()}.png`;
    const filePath = path.join(IMAGES_DIR, fileName);
    fs.writeFileSync(filePath, Buffer.from(imageBase64, "base64"));

    // Add to history index (this is for UI downloads only)
    const url = `/images/${fileName}`;
    historyIndex.push({ prompt, fileName, url });

    res.json({ downloadUrl: url });
  } catch (err) {
    console.error("Generate error:", err);
    res.status(500).json({ error: "Image generation failed" });
  }
});

/**
 * POST /chat
 * Body: { message: "..." }
 * Returns: { reply: "..." }
 */
app.post("/chat", async (req, res) => {
  try {
    const message = (req.body.message || "").toString().trim();
    if (!message) return res.status(400).json({ error: "Message required" });

    // Hidden history record
    appendHistory(`CHAT_MESSAGE: ${message}`);

    const response = await genAI.models.generateContent({
      model: "gemini-2.0-flash",
      contents: [{ role: "user", parts: [{ text: message }] }],
    });

    // Extract text reply
    const candidate = response?.candidates?.[0];
    let reply = "";
    if (candidate && Array.isArray(candidate.content?.parts)) {
      reply = candidate.content.parts.map(p => p.text || "").join("\n");
    }

    res.json({ reply });
  } catch (err) {
    console.error("Chat error:", err);
    res.status(500).json({ error: "Chat failed" });
  }
});

/**
 * GET /history
 * Returns the history index (image entries) — NOTE: UI will hide this by design.
 * Kept available for admin or programmatic uses.
 */
app.get("/history", (req, res) => {
  res.json(historyIndex);
});

/**
 * DELETE /history
 * Clear history index and delete image files. Logs deletions to deletion.log without prompt text.
 */
app.delete("/history", (req, res) => {
  // Delete files
  for (const item of historyIndex) {
    const filePath = path.join(IMAGES_DIR, item.fileName);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
        logDeletion("DELETE_ALL", item.fileName);
      } catch (e) {
        console.warn("Failed to delete", filePath, e);
      }
    }
  }
  historyIndex = [];
  res.json({ message: "History cleared" });
});

/**
 * DELETE /history/:fileName
 * Delete a single history item (and file), logs deletion without prompt text.
 */
app.delete("/history/:fileName", (req, res) => {
  const { fileName } = req.params;
  const idx = historyIndex.findIndex(h => h.fileName === fileName);
  if (idx === -1) return res.status(404).json({ error: "Not found" });

  const filePath = path.join(IMAGES_DIR, fileName);
  if (fs.existsSync(filePath)) {
    try {
      fs.unlinkSync(filePath);
      logDeletion("DELETE_ONE", fileName);
    } catch (e) {
      console.warn("Failed to delete file", filePath, e);
    }
  }
  historyIndex.splice(idx, 1);
  res.json({ message: `Deleted ${fileName}` });
});

// Start
app.listen(PORT, () => {
  console.log(`Server running: http://localhost:${PORT}`);
});
